<?php
require_once __DIR__ . '/../../config/database.php';

class PostController {
    private $db;
    public function __construct() {
        $this->db = Database::getConnection();
        // Auto-create tables if missing
        $this->db->exec("CREATE TABLE IF NOT EXISTS posts (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            content TEXT NOT NULL,
            image_url VARCHAR(255),
            court_id INT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )");
        $this->db->exec("CREATE TABLE IF NOT EXISTS post_likes (
            id INT AUTO_INCREMENT PRIMARY KEY,
            post_id INT NOT NULL,
            user_id INT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY unique_like (post_id, user_id),
            FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )");
    }

    // GET /posts?user_id=X  (user_id for is_liked check, optional)
    public function index() {
        $viewer_id = isset($_GET['user_id']) ? (int)$_GET['user_id'] : 0;
        $stmt = $this->db->prepare("
            SELECT p.id, p.content, p.image_url, p.court_id, p.created_at,
                   u.id AS user_id, u.name AS user_name,
                   (SELECT COUNT(*) FROM post_likes WHERE post_id = p.id) AS likes_count,
                   (SELECT COUNT(*) > 0 FROM post_likes WHERE post_id = p.id AND user_id = :viewer) AS is_liked
            FROM posts p
            JOIN users u ON u.id = p.user_id
            ORDER BY p.created_at DESC
            LIMIT 50
        ");
        $stmt->execute([':viewer' => $viewer_id]);
        $posts = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($posts as &$p) {
            $p['likes_count'] = (int)$p['likes_count'];
            $p['is_liked']    = (bool)$p['is_liked'];
        }
        echo json_encode(['records' => $posts]);
    }

    // POST /posts  { user_id, content, image_url? }
    public function create() {
        $data = json_decode(file_get_contents('php://input'), true);
        $user_id   = (int)($data['user_id'] ?? 0);
        $content   = trim($data['content'] ?? '');
        $image_url = trim($data['image_url'] ?? '');
        $court_id  = isset($data['court_id']) ? (int)$data['court_id'] : null;

        if (!$user_id || !$content) {
            http_response_code(400);
            echo json_encode(['message' => 'user_id and content are required']);
            return;
        }
        $stmt = $this->db->prepare("INSERT INTO posts (user_id, content, image_url, court_id) VALUES (?, ?, ?, ?)");
        $stmt->execute([$user_id, $content, $image_url ?: null, $court_id]);
        $id = $this->db->lastInsertId();

        // Return the created post with user info
        $stmt2 = $this->db->prepare("SELECT p.*, u.name AS user_name FROM posts p JOIN users u ON u.id = p.user_id WHERE p.id = ?");
        $stmt2->execute([$id]);
        $post = $stmt2->fetch(PDO::FETCH_ASSOC);
        $post['likes_count'] = 0;
        $post['is_liked'] = false;
        http_response_code(201);
        echo json_encode($post);
    }

    // DELETE /posts/:id  { user_id }
    public function delete($id) {
        $data    = json_decode(file_get_contents('php://input'), true);
        $user_id = (int)($data['user_id'] ?? 0);
        $stmt = $this->db->prepare("DELETE FROM posts WHERE id = ? AND user_id = ?");
        $stmt->execute([$id, $user_id]);
        if ($stmt->rowCount() === 0) {
            http_response_code(403); echo json_encode(['message' => 'Not found or not yours']); return;
        }
        echo json_encode(['message' => 'Deleted']);
    }

    // POST /posts/:id/like  { user_id }
    public function like($id) {
        $data    = json_decode(file_get_contents('php://input'), true);
        $user_id = (int)($data['user_id'] ?? 0);
        if (!$user_id) { http_response_code(400); echo json_encode(['message' => 'user_id required']); return; }

        // Toggle: try insert, if duplicate — delete
        try {
            $ins = $this->db->prepare("INSERT INTO post_likes (post_id, user_id) VALUES (?, ?)");
            $ins->execute([$id, $user_id]);
            $liked = true;
        } catch (PDOException $e) {
            $del = $this->db->prepare("DELETE FROM post_likes WHERE post_id = ? AND user_id = ?");
            $del->execute([$id, $user_id]);
            $liked = false;
        }
        $cnt = $this->db->prepare("SELECT COUNT(*) FROM post_likes WHERE post_id = ?");
        $cnt->execute([$id]);
        echo json_encode(['liked' => $liked, 'likes_count' => (int)$cnt->fetchColumn()]);
    }
}
