<?php

require_once __DIR__ . '/../Models/User.php';

class AuthController {
    
    // Check if phone exists - to decide whether to show "Enter Name" fields
    // POST /api/auth/check-phone { "phone": "123" }
    public function checkPhone() {
        $data = json_decode(file_get_contents("php://input"));
        
        if(!empty($data->phone)) {
            $user = new User();
            $user->phone = $data->phone;
            $exists = $user->phoneExists();
            
            http_response_code(200);
            echo json_encode(["exists" => $exists]);
        } else {
            http_response_code(400);
            echo json_encode(["message" => "Phone number required"]);
        }
    }

    // Verify OTP and Login/Register
    // POST /api/auth/verify-otp { "phone": "123", "otp": "1234", "name": "Optional", "role": "Optional" }
    public function verifyOtp() {
        $data = json_decode(file_get_contents("php://input"));

        if(empty($data->phone) || empty($data->otp)) {
            http_response_code(400);
            echo json_encode(["message" => "Phone and OTP required"]);
            return;
        }

        // Mock OTP Check
        if($data->otp !== '1234') {
            http_response_code(401);
            echo json_encode(["message" => "Invalid OTP"]);
            return;
        }

        $user = new User();
        $user->phone = $data->phone;

        if($user->phoneExists()) {
            // Login existing user
            $this->sendTokenResponse($user);
        } else {
            // Register new user
            if(empty($data->name)) {
                http_response_code(404);
                echo json_encode(["new_user" => true, "message" => "New user — name required."]);
                return;
            }

            $user->name = $data->name;
            $user->role = 'player'; // all new users are player by default

            try {
                if($user->create()) {
                    // Fetch the new user's ID and data
                    $user->phoneExists();
                    $this->sendTokenResponse($user);
                } else {
                    http_response_code(503);
                    echo json_encode(["message" => "Unable to create user."]);
                }
            } catch (Exception $e) {
                http_response_code(503);
                echo json_encode(["message" => "Unable to create user: " . $e->getMessage()]);
            }
        }
    }

    // PUT /api/auth/profile  { user_id, name }
    public function updateProfile() {
        $data    = json_decode(file_get_contents("php://input"));
        $user_id = (int)($data->user_id ?? 0);
        $name    = trim($data->name ?? '');
        if (!$user_id || !$name) { http_response_code(400); echo json_encode(['message' => 'user_id and name required']); return; }
        $db   = Database::getConnection();
        $stmt = $db->prepare("UPDATE users SET name=? WHERE id=?");
        $stmt->execute([$name, $user_id]);
        // Return updated user
        $uStmt = $db->prepare("SELECT id, name, phone, role FROM users WHERE id=?");
        $uStmt->execute([$user_id]);
        $user = $uStmt->fetch(PDO::FETCH_ASSOC);
        http_response_code(200);
        echo json_encode(['message' => 'Profile updated', 'user' => $user]);
    }

    private function sendTokenResponse($user) {
        $token = bin2hex(random_bytes(16)); // Mock token
        http_response_code(200);
        echo json_encode(array(
            "message" => "Success",
            "token" => $token,
            "user" => array(
                "id" => $user->id,
                "name" => $user->name,
                "phone" => $user->phone, // Ensure Model has public phone property populated if needed, or just echo back
                "role" => $user->role
            )
        ));
    }
}
